//
//  PhotoModel.swift
//  PhotoList
//
//  Created by Hariram on 16/05/24.
//

import Foundation

//MARK: -  Photos Model 
struct PhotosModel:Identifiable,Codable{
    let albumId: Int
    let id: Int
    let title: String
    let url: String
    let thumbnailUrl: String
}
