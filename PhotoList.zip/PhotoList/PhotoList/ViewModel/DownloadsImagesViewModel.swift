//
//  DownloadsImageViewModel.swift
//  PhotoList
//
//  Created by Hariram on 16/05/24.
//

import Foundation
import Combine

//MARK: - Load data for Photos Model
class DownloadingImagesViewModel:ObservableObject{
    
    @Published var photosArray:[PhotosModel] = []
    let service = PhotoModelDataService.instance
    var cancellables = Set<AnyCancellable>()
    
    init(){
      addSubscriber()
    }
    
    func addSubscriber(){
        service.$photoModel
            .sink { [weak self] returnedPhotosModel in
                guard let self = self else {return}
                self.photosArray = returnedPhotosModel
            }
            .store(in: &cancellables)
    }
}
