//
//  DownloadImageViewModel.swift
//  PhotoList
//
//  Created by Hariram on 16/05/24.
//

import SwiftUI
import Foundation
import Combine

//MARK: - Downlaoding Image ViewModel store the values
class DownloadingImageViewModel:ObservableObject{
    
    @Published var isLoading:Bool = false
    @Published var image:UIImage? = nil
    
    
    var cancellables = Set<AnyCancellable>()
    let urlString:String
    let imageKey:String
    
    let manager = CacheManager.instance
    
    init(urlString:String,imagekey:String){
        self.urlString = urlString
        self.imageKey = imagekey
        getImage()
    }
    
    func getImage(){
        if let savedImage = manager.get(key: imageKey){
            self.image = savedImage
            print("GETTING SAVED IMAGE")
        }else{
            downloadImage()
            print("DOWNLOADING IMAGE NOW")
        }
    }
    
    func downloadImage(){
        isLoading = true
        guard let url = URL(string: urlString) else {
            isLoading =  false
            return
        }
        
        URLSession.shared.dataTaskPublisher(for: url)
            .map{UIImage(data: $0.data)}
            .receive(on: DispatchQueue.main)
            .sink { [weak self] _ in
                guard let self = self else {return}
                self.isLoading = false
            } receiveValue: { [weak self] returnedImage in
                guard let self = self,let image = returnedImage else {return}
                self.manager.add(key: self.imageKey, value: image)
                self.image = image
            }
            .store(in: &cancellables)
    }
}
