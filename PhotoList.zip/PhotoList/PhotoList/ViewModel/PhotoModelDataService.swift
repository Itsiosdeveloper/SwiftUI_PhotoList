//
//  PhotoModelDataService.swift
//  PhotoList
//
//  Created by Hariram on 16/05/24.
//

import Foundation
import Combine

struct Constants {
     let Base_Url = "https://jsonplaceholder.typicode.com/"
     let path = "photos"

}

//MARK: - Load data Network Service Handling
class PhotoModelDataService{
    
    static let instance = PhotoModelDataService()
    let constants = Constants()
    private let urlString: String
    @Published var photoModel:[PhotosModel] = []
    var cancellables = Set<AnyCancellable>()
    
    private init(){
        urlString = constants.Base_Url + constants.path
        downloadData()
    }
    
    private func downloadData(){
        guard let url = URL(string: urlString) else {return}
        
        URLSession.shared.dataTaskPublisher(for: url)
            .subscribe(on: DispatchQueue.global(qos: .background))
            .receive(on: DispatchQueue.main)
            .tryMap(handlOutput)
            .decode(type: [PhotosModel].self, decoder: JSONDecoder())
            .sink { completion in
                switch completion{
                case .finished:
                    break
                case .failure(let error):
                    print("Error:- \(error.localizedDescription)")
                }
            } receiveValue: { [weak self] returnedPhotosModel in
                guard let self = self else {return}
                self.photoModel = returnedPhotosModel
            }
            .store(in: &cancellables)
    }
    
    private func handlOutput(output:URLSession.DataTaskPublisher.Output) throws -> Data{
        guard
            let response = output.response as? HTTPURLResponse,
            response.statusCode >= 200 && response.statusCode < 300 else {
            throw URLError(.badServerResponse)
        }
        return output.data
    }
    
}
