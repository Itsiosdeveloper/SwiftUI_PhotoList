//
//  CacheManager.swift
//  PhotoList
//
//  Created by Hariram on 16/05/24.
//

import Foundation
import SwiftUI

//MARK: - Store the Cache Values 
class CacheManager{
    
    static let instance = CacheManager()
    private init(){}
    
    var photoCache:NSCache<NSString, UIImage> = {
        let cache = NSCache<NSString,UIImage>()
        return cache
    }()
    
    func add(key:String,value:UIImage){
        photoCache.setObject(value, forKey: key as NSString)
    }
    
    func get(key:String) -> UIImage?{
        guard let value = photoCache.object(forKey: key as NSString) else {
            return nil
        }
        return value
    }
}
