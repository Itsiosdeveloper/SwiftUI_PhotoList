//
//  ContentView.swift
//  PhotoList
//
//  Created by Hariram on 16/05/24.
//

import SwiftUI

struct ContentView: View {
    
    @StateObject var viewModel = DownloadingImagesViewModel()
    
    var body: some View {
        NavigationView {
            List {
                ForEach(viewModel.photosArray){ model in
                    DownloadImagesRow(model: model)
                }
            }
        }
        .navigationTitle("Photos")
    }
}

struct PhotosView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
