//
//  DownloadImage.swift
//  PhotoList
//
//  Created by Hariram on 16/05/24.
//

import SwiftUI

//MARK: - Download Image for particular row
struct DownloadImagesRow: View {
    let model: PhotosModel
    var body: some View {
        HStack{
            DownloadingImageView(urlString: model.url, imagekey: "\(model.id)")
                .frame(width: 75,height: 75)
            VStack(alignment: .leading){
                Text(model.title)
                    .font(.headline)
            }
            .frame(maxWidth: .infinity,alignment: .leading)
        }
        .padding()
        .background(Rectangle().fill(Color.white))
        .cornerRadius(10)
        .shadow(color: .gray, radius: 3, x: 2, y: 2)
    }
}
