//
//  DownloadingImageView.swift
//  PhotoList
//
//  Created by Hariram on 16/05/24.
//

import Foundation
import SwiftUI

//MARK: - Downloading images from Viewmodel
struct DownloadingImageView: View {
    @StateObject private var loader:DownloadingImageViewModel
    
    init(urlString:String,imagekey:String){
        _loader = StateObject(wrappedValue: DownloadingImageViewModel(urlString: urlString, imagekey: imagekey))
    }
    
    var body: some View {
        ZStack{
            if loader.isLoading{
                Circle()
                    .fill(.gray)
                    .frame(width: 75, height: 75)
            }else if let image = loader.image{
                Image(uiImage: image)
                    .resizable()
                    .clipShape(Circle())
            }
        }
    }
}
