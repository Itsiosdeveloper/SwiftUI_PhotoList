//
//  PhotoListApp.swift
//  PhotoList
//
//  Created by Hariram on 16/05/24.
//

import SwiftUI

@main
struct PhotoListApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
